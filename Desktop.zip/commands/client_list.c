#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void  list(char* message){

    sprintf(message, "LST");
 
}