#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void open_a(char* message, char *userid, char *pass, char *name, char *asset_fname, int start_value, int timeactive){
    





    sprintf(message, "OPA %s %s %s %i %i %s %i %s", userid, pass);
}